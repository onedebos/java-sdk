
package org.openapis.openapi;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Optional;
import org.apache.http.NameValuePair;
import org.openapis.openapi.models.errors.SDKError;
import org.openapis.openapi.models.operations.SDKMethodInterfaces.*;
import org.openapis.openapi.utils.HTTPClient;
import org.openapis.openapi.utils.HTTPRequest;
import org.openapis.openapi.utils.Hook.AfterErrorContextImpl;
import org.openapis.openapi.utils.Hook.AfterSuccessContextImpl;
import org.openapis.openapi.utils.Hook.BeforeRequestContextImpl;
import org.openapis.openapi.utils.JSON;
import org.openapis.openapi.utils.Retries.NonRetryableException;
import org.openapis.openapi.utils.RetryConfig;
import org.openapis.openapi.utils.SerializedBody;
import org.openapis.openapi.utils.SpeakeasyHTTPClient;
import org.openapis.openapi.utils.Utils;
import org.openapitools.jackson.nullable.JsonNullable;

public class AlloySDK implements
            MethodCallUpdateAUser,
            MethodCallGetAUser,
            MethodCallDeleteAUser,
            MethodCallCreateAUser,
            MethodCallListAllUsers,
            MethodCallCreateACredential,
            MethodCallGetCredentialMetadata,
            MethodCallGenerateJwtToken,
            MethodCallListUserCredentials,
            MethodCallListWorkflows,
            MethodCallDeactivateAWorkflow,
            MethodCallActivateAWorkflow,
            MethodCallGetWorkflowAnalytics,
            MethodCallDisableAllWorkflowsForAUser,
            MethodCallGetWorkflowLogs,
            MethodCallGetWorkflowErrors,
            MethodCallDeleteLogsForAUser,
            MethodCallDeleteACredential,
            MethodCallRunEvent,
            MethodCallRerunWorkfow,
            MethodCallRunWorkflow,
            MethodCallListApps,
            MethodCallListIntegrations,
            MethodCallListEvents,
            MethodCallGenerateAlloyLink,
            MethodCallGenerateOauthLink,
            MethodCallDeleteWorkflow,
            MethodCallFindAWorkflow,
            MethodCallGetAnIntegration,
            MethodCallListUsersByWorkflowid,
            MethodCallUpgradeWorkflow,
            MethodCallListVersions,
            MethodCallCredentialMedataByApp,
            MethodCallStartInstallation,
            MethodCallCompleteInstallation {


    /**
     * SERVERS contains the list of server urls available to the SDK.
     */
    public static final String[] SERVERS = {
        "https://embedded.runalloy.com/2024-03/",
    };

    private final SDKConfiguration sdkConfiguration;

    /**
     * The Builder class allows the configuration of a new instance of the SDK.
     */
    public static class Builder {

        private final SDKConfiguration sdkConfiguration = new SDKConfiguration();

        private Builder() {
        }

        /**
         * Allows the default HTTP client to be overridden with a custom implementation.
         *
         * @param client The HTTP client to use for all requests.
         * @return The builder instance.
         */
        public Builder client(HTTPClient client) {
            this.sdkConfiguration.defaultClient = client;
            return this;
        }
        /**
         * Configures the SDK security to use the provided secret.
         *
         * @param sec0 The secret to use for all requests.
         * @return The builder instance.
         */
        public Builder sec0(String sec0) {
            this.sdkConfiguration.securitySource = SecuritySource.of(org.openapis.openapi.models.components.Security.builder()
              .sec0(sec0)
              .build());
            return this;
        }

        /**
         * Configures the SDK to use a custom security source.
         * @param securitySource The security source to use for all requests.
         * @return The builder instance.
         */
        public Builder securitySource(SecuritySource securitySource) {
            this.sdkConfiguration.securitySource = securitySource;
            return this;
        }
        
        /**
         * Overrides the default server URL.
         *
         * @param serverUrl The server URL to use for all requests.
         * @return The builder instance.
         */
        public Builder serverURL(String serverUrl) {
            this.sdkConfiguration.serverUrl = serverUrl;
            return this;
        }

        /**
         * Overrides the default server URL  with a templated URL populated with the provided parameters.
         *
         * @param serverUrl The server URL to use for all requests.
         * @param params The parameters to use when templating the URL.
         * @return The builder instance.
         */
        public Builder serverURL(String serverUrl, java.util.Map<String, String> params) {
            this.sdkConfiguration.serverUrl = org.openapis.openapi.utils.Utils.templateUrl(serverUrl, params);
            return this;
        }
        
        /**
         * Overrides the default server by index.
         *
         * @param serverIdx The server to use for all requests.
         * @return The builder instance.
         */
        public Builder serverIndex(int serverIdx) {
            this.sdkConfiguration.serverIdx = serverIdx;
            this.sdkConfiguration.serverUrl = SERVERS[serverIdx];
            return this;
        }
        
        /**
         * Overrides the default configuration for retries
         *
         * @param retryConfig The retry configuration to use for all requests.
         * @return The builder instance.
         */
        public Builder retryConfig(RetryConfig retryConfig) {
            this.sdkConfiguration.retryConfig = Optional.of(retryConfig);
            return this;
        }
        /**
         * Builds a new instance of the SDK.
         * @return The SDK instance.
         */
        public AlloySDK build() {
            if (sdkConfiguration.defaultClient == null) {
                sdkConfiguration.defaultClient = new SpeakeasyHTTPClient();
            }
	        if (sdkConfiguration.securitySource == null) {
	    	    sdkConfiguration.securitySource = SecuritySource.of(null);
	        }
            if (sdkConfiguration.serverUrl == null || sdkConfiguration.serverUrl.isBlank()) {
                sdkConfiguration.serverUrl = SERVERS[0];
                sdkConfiguration.serverIdx = 0;
            }
            if (sdkConfiguration.serverUrl.endsWith("/")) {
                sdkConfiguration.serverUrl = sdkConfiguration.serverUrl.substring(0, sdkConfiguration.serverUrl.length() - 1);
            }
            return new AlloySDK(sdkConfiguration);
        }
    }
    
    /**
     * Get a new instance of the SDK builder to configure a new instance of the SDK.
     * @return The SDK builder instance.
     */
    public static Builder builder() {
        return new Builder();
    }

    private AlloySDK(SDKConfiguration sdkConfiguration) {
        this.sdkConfiguration = sdkConfiguration;
        this.sdkConfiguration.initialize();
    }
    /**
     * Update a user
     * Updates a user given a specified userId. This endpoint allows you to update a username or fullName and returns the updated user object.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.UpdateAUserRequestBuilder updateAUser() {
        return new org.openapis.openapi.models.operations.UpdateAUserRequestBuilder(this);
    }

    /**
     * Update a user
     * Updates a user given a specified userId. This endpoint allows you to update a username or fullName and returns the updated user object.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.UpdateAUserResponse updateAUser(
            String userId) throws Exception {
        return updateAUser(userId, Optional.empty());
    }
    /**
     * Update a user
     * Updates a user given a specified userId. This endpoint allows you to update a username or fullName and returns the updated user object.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @param requestBody
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.UpdateAUserResponse updateAUser(
            String userId,
            Optional<? extends org.openapis.openapi.models.operations.UpdateAUserRequestBody> requestBody) throws Exception {
        org.openapis.openapi.models.operations.UpdateAUserRequest request =
            org.openapis.openapi.models.operations.UpdateAUserRequest
                .builder()
                .userId(userId)
                .requestBody(requestBody)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.UpdateAUserRequest.class,
                _baseUrl,
                "/users/{userId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "PUT");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<java.lang.Object>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "requestBody", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("update-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "401", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("update-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("update-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("update-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.UpdateAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.UpdateAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.UpdateAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.UpdateAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.UpdateAUserResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "401")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.UpdateAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.UpdateAUserResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a single user
     * Returns a specific user given a userId and any active workflows associated with the user.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetAUserRequestBuilder getAUser() {
        return new org.openapis.openapi.models.operations.GetAUserRequestBuilder(this);
    }

    /**
     * Retrieve a single user
     * Returns a specific user given a userId and any active workflows associated with the user.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetAUserResponse getAUser(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.GetAUserRequest request =
            org.openapis.openapi.models.operations.GetAUserRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GetAUserRequest.class,
                _baseUrl,
                "/users/{userId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "*/*")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Delete a user
     * This endpoint deletes a user account. It is most commonly used when a user stops being a customer of your platform or in conjunction with a GDPR compliance request. Note that this endpoint only deletes the user's account – not any corresponding workflow logs or other data. To remove that data as part of a compliance request, see our 'Delete User Logs' endpoint
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DeleteAUserRequestBuilder deleteAUser() {
        return new org.openapis.openapi.models.operations.DeleteAUserRequestBuilder(this);
    }

    /**
     * Delete a user
     * This endpoint deletes a user account. It is most commonly used when a user stops being a customer of your platform or in conjunction with a GDPR compliance request. Note that this endpoint only deletes the user's account – not any corresponding workflow logs or other data. To remove that data as part of a compliance request, see our 'Delete User Logs' endpoint
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeleteAUserResponse deleteAUser(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.DeleteAUserRequest request =
            org.openapis.openapi.models.operations.DeleteAUserRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.DeleteAUserRequest.class,
                _baseUrl,
                "/users/{userId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "DELETE");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("delete-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "401", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("delete-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("delete-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("delete-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DeleteAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DeleteAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DeleteAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DeleteAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DeleteAUserResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "401")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.DeleteAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.DeleteAUserResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Create a user
     * Creates a new user in your Embedded account. The user record acts like a "container" to store all the integrations, workflows, and credentials for any given user. Returns a user identifier.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.CreateAUserRequestBuilder createAUser() {
        return new org.openapis.openapi.models.operations.CreateAUserRequestBuilder(this);
    }

    /**
     * Create a user
     * Creates a new user in your Embedded account. The user record acts like a "container" to store all the integrations, workflows, and credentials for any given user. Returns a user identifier.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CreateAUserResponse createAUserDirect() throws Exception {
        return createAUser(Optional.empty());
    }
    /**
     * Create a user
     * Creates a new user in your Embedded account. The user record acts like a "container" to store all the integrations, workflows, and credentials for any given user. Returns a user identifier.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CreateAUserResponse createAUser(
            Optional<? extends org.openapis.openapi.models.operations.CreateAUserRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/users/");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.CreateAUserRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("create-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "401", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("create-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("create-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("create-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.CreateAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.CreateAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.CreateAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.CreateAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.CreateAUserResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "401")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.CreateAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.CreateAUserResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a list of all users
     * Returns a list of all users created in your Embedded account.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListAllUsersRequestBuilder listAllUsers() {
        return new org.openapis.openapi.models.operations.ListAllUsersRequestBuilder(this);
    }

    /**
     * Retrieve a list of all users
     * Returns a list of all users created in your Embedded account.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListAllUsersResponse listAllUsersDirect() throws Exception {
        return listAllUsers(Optional.empty());
    }
    /**
     * Retrieve a list of all users
     * Returns a list of all users created in your Embedded account.
     * @param parentWorkflowId You can pass a parentWorkflowId if you wish to list users for a specific workflow.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListAllUsersResponse listAllUsers(
            Optional<? extends String> parentWorkflowId) throws Exception {
        org.openapis.openapi.models.operations.ListAllUsersRequest request =
            org.openapis.openapi.models.operations.ListAllUsersRequest
                .builder()
                .parentWorkflowId(parentWorkflowId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/users");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.ListAllUsersRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-all-users", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "401", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-all-users", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-all-users", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-all-users", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListAllUsersResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListAllUsersResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListAllUsersResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ListAllUsersResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ListAllUsersResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "401")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListAllUsersResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListAllUsersResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Create Credential
     * Use this endpoint to add a credential programmatically via the API. This endpoint should be used primarily for non-OAuth blocks. If you are using Secrets Manager with an OAuth block and you have the OAuth tokens already, you can add them to Alloy with this endpoint. Please reference [this](https://docs.runalloy.com/docs/headless) section of our docs for a complete tutorial on when and how to use this endpoint.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.CreateACredentialRequestBuilder createACredential() {
        return new org.openapis.openapi.models.operations.CreateACredentialRequestBuilder(this);
    }

    /**
     * Create Credential
     * Use this endpoint to add a credential programmatically via the API. This endpoint should be used primarily for non-OAuth blocks. If you are using Secrets Manager with an OAuth block and you have the OAuth tokens already, you can add them to Alloy with this endpoint. Please reference [this](https://docs.runalloy.com/docs/headless) section of our docs for a complete tutorial on when and how to use this endpoint.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CreateACredentialResponse createACredentialDirect() throws Exception {
        return createACredential(Optional.empty());
    }
    /**
     * Create Credential
     * Use this endpoint to add a credential programmatically via the API. This endpoint should be used primarily for non-OAuth blocks. If you are using Secrets Manager with an OAuth block and you have the OAuth tokens already, you can add them to Alloy with this endpoint. Please reference [this](https://docs.runalloy.com/docs/headless) section of our docs for a complete tutorial on when and how to use this endpoint.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CreateACredentialResponse createACredential(
            Optional<? extends org.openapis.openapi.models.operations.CreateACredentialRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/headless/credentials");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.CreateACredentialRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("create-a-credential", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("create-a-credential", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("create-a-credential", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("create-a-credential", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.CreateACredentialResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.CreateACredentialResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.CreateACredentialResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.CreateACredentialResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.CreateACredentialResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve all credential structures
     * This endpoint returns a basic structure of what data must be inputted when adding a credential manually. This should be used when creating a credential using the POST credential endpoint.
     * 
     * This endpoint returns the structure of every supported block on Alloy Embedded. It returns a boolean flag called `isOauth` which indicates if the credential uses OAuth or an API key.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetCredentialMetadataRequestBuilder getCredentialMetadata() {
        return new org.openapis.openapi.models.operations.GetCredentialMetadataRequestBuilder(this);
    }

    /**
     * Retrieve all credential structures
     * This endpoint returns a basic structure of what data must be inputted when adding a credential manually. This should be used when creating a credential using the POST credential endpoint.
     * 
     * This endpoint returns the structure of every supported block on Alloy Embedded. It returns a boolean flag called `isOauth` which indicates if the credential uses OAuth or an API key.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetCredentialMetadataResponse getCredentialMetadataDirect() throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/metadata/credentials");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-credential-metadata", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-credential-metadata", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-credential-metadata", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-credential-metadata", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetCredentialMetadataResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetCredentialMetadataResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetCredentialMetadataResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GetCredentialMetadataResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GetCredentialMetadataResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Generate a new JWT for a user
     * This endpoint is used to generate a new user token in the form of a JSON Web Token (JWT) which is required to securely render the Embedded Modal in your application. Once retrieved, you'll want to pass this token to your frontend.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GenerateJwtTokenRequestBuilder generateJwtToken() {
        return new org.openapis.openapi.models.operations.GenerateJwtTokenRequestBuilder(this);
    }

    /**
     * Generate a new JWT for a user
     * This endpoint is used to generate a new user token in the form of a JSON Web Token (JWT) which is required to securely render the Embedded Modal in your application. Once retrieved, you'll want to pass this token to your frontend.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GenerateJwtTokenResponse generateJwtToken(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.GenerateJwtTokenRequest request =
            org.openapis.openapi.models.operations.GenerateJwtTokenRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GenerateJwtTokenRequest.class,
                _baseUrl,
                "/users/{userId}/token",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("generate-jwt-token", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("generate-jwt-token", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("generate-jwt-token", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("generate-jwt-token", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GenerateJwtTokenResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GenerateJwtTokenResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GenerateJwtTokenResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GenerateJwtTokenResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GenerateJwtTokenResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve all credentials for a user
     * Returns a list of all credentials created for a specified user.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListUserCredentialsRequestBuilder listUserCredentials() {
        return new org.openapis.openapi.models.operations.ListUserCredentialsRequestBuilder(this);
    }

    /**
     * Retrieve all credentials for a user
     * Returns a list of all credentials created for a specified user.
     * @param userId The id of the currently logged in user
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListUserCredentialsResponse listUserCredentials(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.ListUserCredentialsRequest request =
            org.openapis.openapi.models.operations.ListUserCredentialsRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.ListUserCredentialsRequest.class,
                _baseUrl,
                "/users/{userId}/credentials",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-user-credentials", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-user-credentials", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-user-credentials", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-user-credentials", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListUserCredentialsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListUserCredentialsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListUserCredentialsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ListUserCredentialsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ListUserCredentialsResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a list of workflows
     * Returns a list of all active **parent** workflows associated with your Alloy Embedded account. Note this endpoint does _not_ return a list of workflows that the user has installed, but rather a list of all _available_ workflows. The `installed` flag indicates if the user has installed a copy of the workflow but does not  indicate if the user has a given workflow "active".
     * 
     * For each workflow, this endpoint returns the individual apps that are required as part of the workflow. Commonly used to populate data on an integrations page.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListWorkflowsRequestBuilder listWorkflows() {
        return new org.openapis.openapi.models.operations.ListWorkflowsRequestBuilder(this);
    }

    /**
     * Retrieve a list of workflows
     * Returns a list of all active **parent** workflows associated with your Alloy Embedded account. Note this endpoint does _not_ return a list of workflows that the user has installed, but rather a list of all _available_ workflows. The `installed` flag indicates if the user has installed a copy of the workflow but does not  indicate if the user has a given workflow "active".
     * 
     * For each workflow, this endpoint returns the individual apps that are required as part of the workflow. Commonly used to populate data on an integrations page.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListWorkflowsResponse listWorkflows(
            String userId) throws Exception {
        return listWorkflows(Optional.empty(), userId);
    }
    /**
     * Retrieve a list of workflows
     * Returns a list of all active **parent** workflows associated with your Alloy Embedded account. Note this endpoint does _not_ return a list of workflows that the user has installed, but rather a list of all _available_ workflows. The `installed` flag indicates if the user has installed a copy of the workflow but does not  indicate if the user has a given workflow "active".
     * 
     * For each workflow, this endpoint returns the individual apps that are required as part of the workflow. Commonly used to populate data on an integrations page.
     * @param integration This parameter allows you to filter workflows based on the name of the integration you're looking for. For example, if you were looking for a Shopify integration, specify shopify
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListWorkflowsResponse listWorkflows(
            Optional<? extends String> integration,
            String userId) throws Exception {
        org.openapis.openapi.models.operations.ListWorkflowsRequest request =
            org.openapis.openapi.models.operations.ListWorkflowsRequest
                .builder()
                .integration(integration)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/workflows/");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.ListWorkflowsRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-workflows", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-workflows", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-workflows", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-workflows", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListWorkflowsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListWorkflowsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListWorkflowsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ListWorkflowsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ListWorkflowsResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListWorkflowsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListWorkflowsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Deactivate a workflow
     * Disables all future invocations and runs for a given workflow. 
     * 
     * By deactivating a workflow, this endpoint will turn off any events or webhooks a workflow is subscribed to. May be reactivated by the Reactivate workflow endpoint.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DeactivateAWorkflowRequestBuilder deactivateAWorkflow() {
        return new org.openapis.openapi.models.operations.DeactivateAWorkflowRequestBuilder(this);
    }

    /**
     * Deactivate a workflow
     * Disables all future invocations and runs for a given workflow. 
     * 
     * By deactivating a workflow, this endpoint will turn off any events or webhooks a workflow is subscribed to. May be reactivated by the Reactivate workflow endpoint.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeactivateAWorkflowResponse deactivateAWorkflowDirect() throws Exception {
        return deactivateAWorkflow(Optional.empty());
    }
    /**
     * Deactivate a workflow
     * Disables all future invocations and runs for a given workflow. 
     * 
     * By deactivating a workflow, this endpoint will turn off any events or webhooks a workflow is subscribed to. May be reactivated by the Reactivate workflow endpoint.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeactivateAWorkflowResponse deactivateAWorkflow(
            Optional<? extends org.openapis.openapi.models.operations.DeactivateAWorkflowRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/workflows/deactivate");
        
        HTTPRequest _req = new HTTPRequest(_url, "PUT");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.DeactivateAWorkflowRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("deactivate-a-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("deactivate-a-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("deactivate-a-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("deactivate-a-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DeactivateAWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DeactivateAWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DeactivateAWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DeactivateAWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DeactivateAWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Activate a workflow
     * Reactivates a workflow that was previously disabled by the Disable Workflow endpoint. This endpoint requires a specified WorkflowId and returns a success/failure.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ActivateAWorkflowRequestBuilder activateAWorkflow() {
        return new org.openapis.openapi.models.operations.ActivateAWorkflowRequestBuilder(this);
    }

    /**
     * Activate a workflow
     * Reactivates a workflow that was previously disabled by the Disable Workflow endpoint. This endpoint requires a specified WorkflowId and returns a success/failure.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ActivateAWorkflowResponse activateAWorkflowDirect() throws Exception {
        return activateAWorkflow(Optional.empty());
    }
    /**
     * Activate a workflow
     * Reactivates a workflow that was previously disabled by the Disable Workflow endpoint. This endpoint requires a specified WorkflowId and returns a success/failure.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ActivateAWorkflowResponse activateAWorkflow(
            Optional<? extends org.openapis.openapi.models.operations.ActivateAWorkflowRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/workflows/activate");
        
        HTTPRequest _req = new HTTPRequest(_url, "PUT");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.ActivateAWorkflowRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("activate-a-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("activate-a-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("activate-a-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("activate-a-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ActivateAWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ActivateAWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ActivateAWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ActivateAWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ActivateAWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve usage metrics for a workflow
     * This endpoint returns the `totalAppActions` (the number of times each block inside the workflow has been executed over the course of the workflow's lifetime), the `totalWorkflowRuns` (which represents the number of times the workflow has been invoked) and the `totalErrors` (the number of times the workflow has had an error).
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetWorkflowAnalyticsRequestBuilder getWorkflowAnalytics() {
        return new org.openapis.openapi.models.operations.GetWorkflowAnalyticsRequestBuilder(this);
    }

    /**
     * Retrieve usage metrics for a workflow
     * This endpoint returns the `totalAppActions` (the number of times each block inside the workflow has been executed over the course of the workflow's lifetime), the `totalWorkflowRuns` (which represents the number of times the workflow has been invoked) and the `totalErrors` (the number of times the workflow has had an error).
     * @param workflowId The Id of the workflow you want to find errors for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponse getWorkflowAnalytics(
            String workflowId) throws Exception {
        org.openapis.openapi.models.operations.GetWorkflowAnalyticsRequest request =
            org.openapis.openapi.models.operations.GetWorkflowAnalyticsRequest
                .builder()
                .workflowId(workflowId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GetWorkflowAnalyticsRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/analytics",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-workflow-analytics", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-workflow-analytics", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-workflow-analytics", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-workflow-analytics", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GetWorkflowAnalyticsResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Deactivate workflows for a user
     * Deactivates all active workflows for a user in bulk. 
     * 
     * This endpoint may be used to perform a bulk operation such as temporarily disabling a user's account in lieu of deleting the user account if the user wants to "pause" their account.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserRequestBuilder disableAllWorkflowsForAUser() {
        return new org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserRequestBuilder(this);
    }

    /**
     * Deactivate workflows for a user
     * Deactivates all active workflows for a user in bulk. 
     * 
     * This endpoint may be used to perform a bulk operation such as temporarily disabling a user's account in lieu of deleting the user account if the user wants to "pause" their account.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponse disableAllWorkflowsForAUser(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserRequest request =
            org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserRequest.class,
                _baseUrl,
                "/users/{userId}/deactivate-workflows",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "PUT");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("disable-all-workflows-for-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("disable-all-workflows-for-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("disable-all-workflows-for-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("disable-all-workflows-for-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DisableAllWorkflowsForAUserResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve all execution logs for a workflow
     * Retrieves log data for a given workflow over time. Logs are stored for a maximum of 60 days before being purged.
     * 
     * Each log includes the `executionId` (which can be used to rerun an execution), the `startedAt` and `stoppedAt` date stamps, and the JSON output of the execution.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetWorkflowLogsRequestBuilder getWorkflowLogs() {
        return new org.openapis.openapi.models.operations.GetWorkflowLogsRequestBuilder(this);
    }

    /**
     * Retrieve all execution logs for a workflow
     * Retrieves log data for a given workflow over time. Logs are stored for a maximum of 60 days before being purged.
     * 
     * Each log includes the `executionId` (which can be used to rerun an execution), the `startedAt` and `stoppedAt` date stamps, and the JSON output of the execution.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetWorkflowLogsResponse getWorkflowLogs(
            org.openapis.openapi.models.operations.GetWorkflowLogsRequest request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GetWorkflowLogsRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/logs",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "*/*")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.GetWorkflowLogsRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-workflow-logs", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-workflow-logs", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-workflow-logs", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-workflow-logs", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetWorkflowLogsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetWorkflowLogsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetWorkflowLogsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve all error logs for a workflow
     * This endpoint fetches an array of errors for a specific workflow.
     * 
     * It returns the error message, and the date stamp when the error was thrown, the block that caused the error, and the `workflowId` . Commonly used to debug workflows when they error and identify historical errors; this endpoint may be used in conjunction with the route error messages feature.
     * 
     * If there are no errors for the specified workflow, this endpoint will return an empty array.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetWorkflowErrorsRequestBuilder getWorkflowErrors() {
        return new org.openapis.openapi.models.operations.GetWorkflowErrorsRequestBuilder(this);
    }

    /**
     * Retrieve all error logs for a workflow
     * This endpoint fetches an array of errors for a specific workflow.
     * 
     * It returns the error message, and the date stamp when the error was thrown, the block that caused the error, and the `workflowId` . Commonly used to debug workflows when they error and identify historical errors; this endpoint may be used in conjunction with the route error messages feature.
     * 
     * If there are no errors for the specified workflow, this endpoint will return an empty array.
     * @param workflowId The Id of the workflow you want to find errors for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetWorkflowErrorsResponse getWorkflowErrors(
            String workflowId) throws Exception {
        return getWorkflowErrors(workflowId, Optional.empty());
    }
    /**
     * Retrieve all error logs for a workflow
     * This endpoint fetches an array of errors for a specific workflow.
     * 
     * It returns the error message, and the date stamp when the error was thrown, the block that caused the error, and the `workflowId` . Commonly used to debug workflows when they error and identify historical errors; this endpoint may be used in conjunction with the route error messages feature.
     * 
     * If there are no errors for the specified workflow, this endpoint will return an empty array.
     * @param workflowId The Id of the workflow you want to find errors for
     * @param userId The Id of the user you want delete logs for. Returned from the Create User endpoint
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetWorkflowErrorsResponse getWorkflowErrors(
            String workflowId,
            Optional<? extends String> userId) throws Exception {
        org.openapis.openapi.models.operations.GetWorkflowErrorsRequest request =
            org.openapis.openapi.models.operations.GetWorkflowErrorsRequest
                .builder()
                .workflowId(workflowId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GetWorkflowErrorsRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/errors",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.GetWorkflowErrorsRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-workflow-errors", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-workflow-errors", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-workflow-errors", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-workflow-errors", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetWorkflowErrorsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetWorkflowErrorsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetWorkflowErrorsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.GetWorkflowErrorsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.GetWorkflowErrorsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Delete all logs for a user
     * This endpoint deletes all historical logs associated with a user and is most commonly used in conjunction with a compliance request such as GDPR. This endpoint requires a userId. 
     * 
     * Note that this action cannot be undone.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DeleteLogsForAUserRequestBuilder deleteLogsForAUser() {
        return new org.openapis.openapi.models.operations.DeleteLogsForAUserRequestBuilder(this);
    }

    /**
     * Delete all logs for a user
     * This endpoint deletes all historical logs associated with a user and is most commonly used in conjunction with a compliance request such as GDPR. This endpoint requires a userId. 
     * 
     * Note that this action cannot be undone.
     * @param userId The Id of the user you want delete logs for. Returned from the Create User endpoint
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeleteLogsForAUserResponse deleteLogsForAUser(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.DeleteLogsForAUserRequest request =
            org.openapis.openapi.models.operations.DeleteLogsForAUserRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.DeleteLogsForAUserRequest.class,
                _baseUrl,
                "/users/{userId}/logs",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "DELETE");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("delete-logs-for-a-user", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("delete-logs-for-a-user", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("delete-logs-for-a-user", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("delete-logs-for-a-user", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DeleteLogsForAUserResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DeleteLogsForAUserResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DeleteLogsForAUserResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DeleteLogsForAUserResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DeleteLogsForAUserResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Delete a Credential for a user
     * To delete a credential via the API, you need to invoke the below endpoint.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DeleteACredentialRequestBuilder deleteACredential() {
        return new org.openapis.openapi.models.operations.DeleteACredentialRequestBuilder(this);
    }

    /**
     * Delete a Credential for a user
     * To delete a credential via the API, you need to invoke the below endpoint.
     * @param credentialId The credential you're looking to delete
     * @param userId The Id of the user associated with this credential
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeleteACredentialResponse deleteACredential(
            String credentialId,
            String userId) throws Exception {
        org.openapis.openapi.models.operations.DeleteACredentialRequest request =
            org.openapis.openapi.models.operations.DeleteACredentialRequest
                .builder()
                .credentialId(credentialId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.DeleteACredentialRequest.class,
                _baseUrl,
                "/users/{userId}/credentials/{credentialId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "DELETE");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("delete-a-credential", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("delete-a-credential", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("delete-a-credential", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("delete-a-credential", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DeleteACredentialResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DeleteACredentialResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DeleteACredentialResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DeleteACredentialResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DeleteACredentialResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Trigger an event for a user
     * This endpoint runs a workflow that uses a **Custom Event **. Note that this endpoint cannot be used to invoke a workflow that has a Custom Webhook Trigger.
     * 
     * If you have defined a custom JSON body for the Custom Event, it should be passed into the `data` body parameter.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.RunEventRequestBuilder runEvent() {
        return new org.openapis.openapi.models.operations.RunEventRequestBuilder(this);
    }

    /**
     * Trigger an event for a user
     * This endpoint runs a workflow that uses a **Custom Event **. Note that this endpoint cannot be used to invoke a workflow that has a Custom Webhook Trigger.
     * 
     * If you have defined a custom JSON body for the Custom Event, it should be passed into the `data` body parameter.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.RunEventResponse runEventDirect() throws Exception {
        return runEvent(Optional.empty());
    }
    /**
     * Trigger an event for a user
     * This endpoint runs a workflow that uses a **Custom Event **. Note that this endpoint cannot be used to invoke a workflow that has a Custom Webhook Trigger.
     * 
     * If you have defined a custom JSON body for the Custom Event, it should be passed into the `data` body parameter.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.RunEventResponse runEvent(
            Optional<? extends org.openapis.openapi.models.operations.RunEventRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/run/event");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.RunEventRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("run-event", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("run-event", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("run-event", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("run-event", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.RunEventResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.RunEventResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.RunEventResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.RunEventResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.RunEventResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Rerun a single workflow execution
     * Retrieves log data for a given workflow over time. Logs are stored for a maximum of 60 days before being purged.
     * 
     * Each log includes the `executionId` (which can be used to rerun an execution), the `startedAt` and `stoppedAt` date stamps, and the JSON output of the execution.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.RerunWorkfowRequestBuilder rerunWorkfow() {
        return new org.openapis.openapi.models.operations.RerunWorkfowRequestBuilder(this);
    }

    /**
     * Rerun a single workflow execution
     * Retrieves log data for a given workflow over time. Logs are stored for a maximum of 60 days before being purged.
     * 
     * Each log includes the `executionId` (which can be used to rerun an execution), the `startedAt` and `stoppedAt` date stamps, and the JSON output of the execution.
     * @param workflowId The Id of the workflow you want to find logs for
     * @param executionId The Id of the execution to rerun. This can be retrieved from the GET Workflow Logs endpoint
     * @param userId The Id of the user you want delete logs for. Returned from the Create User endpoint
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.RerunWorkfowResponse rerunWorkfow(
            String workflowId,
            String executionId,
            String userId) throws Exception {
        org.openapis.openapi.models.operations.RerunWorkfowRequest request =
            org.openapis.openapi.models.operations.RerunWorkfowRequest
                .builder()
                .workflowId(workflowId)
                .executionId(executionId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.RerunWorkfowRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/rerun/{executionId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.RerunWorkfowRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("rerun-workfow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("rerun-workfow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("rerun-workfow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("rerun-workfow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.RerunWorkfowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.RerunWorkfowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.RerunWorkfowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.RerunWorkfowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.RerunWorkfowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Run Workflow
     * This endpoint runs a workflow that uses a **Webhook Trigger.** Note that this endpoint should not be used to invoke a workflow that has a Custom Event. If you have defined a custom JSON body for the webhook trigger, it should be passed into the `data` body parameter.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.RunWorkflowRequestBuilder runWorkflow() {
        return new org.openapis.openapi.models.operations.RunWorkflowRequestBuilder(this);
    }

    /**
     * Run Workflow
     * This endpoint runs a workflow that uses a **Webhook Trigger.** Note that this endpoint should not be used to invoke a workflow that has a Custom Event. If you have defined a custom JSON body for the webhook trigger, it should be passed into the `data` body parameter.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.RunWorkflowResponse runWorkflowDirect() throws Exception {
        return runWorkflow(Optional.empty());
    }
    /**
     * Run Workflow
     * This endpoint runs a workflow that uses a **Webhook Trigger.** Note that this endpoint should not be used to invoke a workflow that has a Custom Event. If you have defined a custom JSON body for the webhook trigger, it should be passed into the `data` body parameter.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.RunWorkflowResponse runWorkflow(
            Optional<? extends org.openapis.openapi.models.operations.RunWorkflowRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/run/workflow");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.RunWorkflowRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("run-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("run-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("run-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("run-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.RunWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.RunWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.RunWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.RunWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.RunWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve all supported apps
     * Returns all the available apps currently supported by Alloy Embedded
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListAppsRequestBuilder listApps() {
        return new org.openapis.openapi.models.operations.ListAppsRequestBuilder(this);
    }

    /**
     * Retrieve all supported apps
     * Returns all the available apps currently supported by Alloy Embedded
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListAppsResponse listAppsDirect() throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/metadata/apps");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-apps", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-apps", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-apps", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-apps", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListAppsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListAppsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListAppsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListAppsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListAppsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a list of all integrations
     * Returns all the available integrations in your Alloy Embedded Account. Includes integrations/apps you've created an "integration" for, their workflows and statuses. If `installed` equals `true`, the `installedVersion` key will show the currently installed version.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListIntegrationsRequestBuilder listIntegrations() {
        return new org.openapis.openapi.models.operations.ListIntegrationsRequestBuilder(this);
    }

    /**
     * Retrieve a list of all integrations
     * Returns all the available integrations in your Alloy Embedded Account. Includes integrations/apps you've created an "integration" for, their workflows and statuses. If `installed` equals `true`, the `installedVersion` key will show the currently installed version.
     * @param userId The Id used to identify the user. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListIntegrationsResponse listIntegrations(
            String userId) throws Exception {
        org.openapis.openapi.models.operations.ListIntegrationsRequest request =
            org.openapis.openapi.models.operations.ListIntegrationsRequest
                .builder()
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/integrations");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.ListIntegrationsRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-integrations", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-integrations", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-integrations", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-integrations", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListIntegrationsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListIntegrationsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListIntegrationsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ListIntegrationsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ListIntegrationsResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListIntegrationsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListIntegrationsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a list of custom events
     * Returns a list of all Custom Events you have enabled in Alloy Embedded.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListEventsRequestBuilder listEvents() {
        return new org.openapis.openapi.models.operations.ListEventsRequestBuilder(this);
    }

    /**
     * Retrieve a list of custom events
     * Returns a list of all Custom Events you have enabled in Alloy Embedded.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListEventsResponse listEventsDirect() throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/events");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-events", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-events", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-events", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-events", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListEventsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListEventsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListEventsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.ListEventsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.ListEventsResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListEventsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListEventsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Create an Embedded link for an integration
     * This endpoint generates an alloy Link. For more details on Embedded Link, please [read](https://docs.runalloy.com/docs/alloy-link) this tutorial.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GenerateAlloyLinkRequestBuilder generateAlloyLink() {
        return new org.openapis.openapi.models.operations.GenerateAlloyLinkRequestBuilder(this);
    }

    /**
     * Create an Embedded link for an integration
     * This endpoint generates an alloy Link. For more details on Embedded Link, please [read](https://docs.runalloy.com/docs/alloy-link) this tutorial.
     * @param userId The user to generate the Embedded Link for
     * @param integrationId The Id of the integration you want to generate the Embedded Link for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GenerateAlloyLinkResponse generateAlloyLink(
            String userId,
            String integrationId) throws Exception {
        org.openapis.openapi.models.operations.GenerateAlloyLinkRequest request =
            org.openapis.openapi.models.operations.GenerateAlloyLinkRequest
                .builder()
                .userId(userId)
                .integrationId(integrationId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GenerateAlloyLinkRequest.class,
                _baseUrl,
                "/users/{userId}/integrations/{integrationId}/install-url",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("generate-alloy-link", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("generate-alloy-link", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("generate-alloy-link", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("generate-alloy-link", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GenerateAlloyLinkResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GenerateAlloyLinkResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GenerateAlloyLinkResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GenerateAlloyLinkResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GenerateAlloyLinkResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Create OAuth Link
     * This endpoint can be used to generate an OAuth link if you want to completely white label your authentication experience. You can use this endpoint to generate a link which your users can click to redirect to the specified application without rendering the Alloy Embedded Modal.
     * 
     * Note: this endpoint **only** works with OAuth enabled integrations. To add a credential manually, please use the [POST Create Credential API](https://docs.runalloy.com/v2.1/reference/create-a-credential).
     * 
     * This endpoint takes a `userId`, `integrationId`, and `credentialName` as inputs. It should be used in conjunction with the [GET Credential Metadata API](https://docs.runalloy.com/v2.1/reference/get-credential-metadata). `credentialName` represents the name of the integration you want to call.
     * 
     * If the credential metadata endpoint returns any `properties,` you must pass them as query string parameters at the end of this call.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GenerateOauthLinkRequestBuilder generateOauthLink() {
        return new org.openapis.openapi.models.operations.GenerateOauthLinkRequestBuilder(this);
    }

    /**
     * Create OAuth Link
     * This endpoint can be used to generate an OAuth link if you want to completely white label your authentication experience. You can use this endpoint to generate a link which your users can click to redirect to the specified application without rendering the Alloy Embedded Modal.
     * 
     * Note: this endpoint **only** works with OAuth enabled integrations. To add a credential manually, please use the [POST Create Credential API](https://docs.runalloy.com/v2.1/reference/create-a-credential).
     * 
     * This endpoint takes a `userId`, `integrationId`, and `credentialName` as inputs. It should be used in conjunction with the [GET Credential Metadata API](https://docs.runalloy.com/v2.1/reference/get-credential-metadata). `credentialName` represents the name of the integration you want to call.
     * 
     * If the credential metadata endpoint returns any `properties,` you must pass them as query string parameters at the end of this call.
     * @param userId The id of the user to generate this link for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GenerateOauthLinkResponse generateOauthLink(
            String userId) throws Exception {
        return generateOauthLink(userId, Optional.empty(), Optional.empty());
    }
    /**
     * Create OAuth Link
     * This endpoint can be used to generate an OAuth link if you want to completely white label your authentication experience. You can use this endpoint to generate a link which your users can click to redirect to the specified application without rendering the Alloy Embedded Modal.
     * 
     * Note: this endpoint **only** works with OAuth enabled integrations. To add a credential manually, please use the [POST Create Credential API](https://docs.runalloy.com/v2.1/reference/create-a-credential).
     * 
     * This endpoint takes a `userId`, `integrationId`, and `credentialName` as inputs. It should be used in conjunction with the [GET Credential Metadata API](https://docs.runalloy.com/v2.1/reference/get-credential-metadata). `credentialName` represents the name of the integration you want to call.
     * 
     * If the credential metadata endpoint returns any `properties,` you must pass them as query string parameters at the end of this call.
     * @param userId The id of the user to generate this link for
     * @param app The name of the app you want the user to authorize access to
     * @param credentialName
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GenerateOauthLinkResponse generateOauthLink(
            String userId,
            Optional<? extends String> app,
            Optional<? extends String> credentialName) throws Exception {
        org.openapis.openapi.models.operations.GenerateOauthLinkRequest request =
            org.openapis.openapi.models.operations.GenerateOauthLinkRequest
                .builder()
                .userId(userId)
                .app(app)
                .credentialName(credentialName)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/headless/oauthUrl");
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.GenerateOauthLinkRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("generate-oauth-link", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("generate-oauth-link", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("generate-oauth-link", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("generate-oauth-link", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GenerateOauthLinkResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GenerateOauthLinkResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GenerateOauthLinkResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GenerateOauthLinkResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GenerateOauthLinkResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Delete a workflow
     * Deletes a workflow for a specific user. This endpoint does not delete a workflow for all users.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.DeleteWorkflowRequestBuilder deleteWorkflow() {
        return new org.openapis.openapi.models.operations.DeleteWorkflowRequestBuilder(this);
    }

    /**
     * Delete a workflow
     * Deletes a workflow for a specific user. This endpoint does not delete a workflow for all users.
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @param workflowId The Id of the workflow to delete
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.DeleteWorkflowResponse deleteWorkflow(
            String userId,
            String workflowId) throws Exception {
        org.openapis.openapi.models.operations.DeleteWorkflowRequest request =
            org.openapis.openapi.models.operations.DeleteWorkflowRequest
                .builder()
                .userId(userId)
                .workflowId(workflowId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.DeleteWorkflowRequest.class,
                _baseUrl,
                "/workflows/{workflowId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "DELETE");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.DeleteWorkflowRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("delete-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("delete-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("delete-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("delete-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.DeleteWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.DeleteWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.DeleteWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.DeleteWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.DeleteWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a single workflow
     * Find a workflow given a workflowId
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.FindAWorkflowRequestBuilder findAWorkflow() {
        return new org.openapis.openapi.models.operations.FindAWorkflowRequestBuilder(this);
    }

    /**
     * Retrieve a single workflow
     * Find a workflow given a workflowId
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @param workflowId The Id of the workflow to find
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.FindAWorkflowResponse findAWorkflow(
            String userId,
            String workflowId) throws Exception {
        org.openapis.openapi.models.operations.FindAWorkflowRequest request =
            org.openapis.openapi.models.operations.FindAWorkflowRequest
                .builder()
                .userId(userId)
                .workflowId(workflowId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.FindAWorkflowRequest.class,
                _baseUrl,
                "/workflows/{workflowId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.FindAWorkflowRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("find-a-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("find-a-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("find-a-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("find-a-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.FindAWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.FindAWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.FindAWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.FindAWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.FindAWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a single integration
     * Finds a specific integration for a user
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.GetAnIntegrationRequestBuilder getAnIntegration() {
        return new org.openapis.openapi.models.operations.GetAnIntegrationRequestBuilder(this);
    }

    /**
     * Retrieve a single integration
     * Finds a specific integration for a user
     * @param integrationId This API parameter allows you to filter results based on the integrationId or the integrationName (also referred to as 'app'). The integration name (app) is a custom name that you have set for your integration. When using the integration name (app), provide the name of the integration you want to filter for (e.g. 'shopify order sync' or 'magento product creation'). You can obtain the integration name (app) from the List Integrations endpoint under the 'app' parameter, or by checking your UI. Either integrationId or integrationName must be provided but it cannot be both.
     * @param userId The Id used to identify the user. Note: you can also use the Embedded user's `username` in this field.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.GetAnIntegrationResponse getAnIntegration(
            String integrationId,
            String userId) throws Exception {
        org.openapis.openapi.models.operations.GetAnIntegrationRequest request =
            org.openapis.openapi.models.operations.GetAnIntegrationRequest
                .builder()
                .integrationId(integrationId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.GetAnIntegrationRequest.class,
                _baseUrl,
                "/integrations/{integrationId}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.GetAnIntegrationRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("get-an-integration", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("get-an-integration", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("get-an-integration", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("get-an-integration", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.GetAnIntegrationResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.GetAnIntegrationResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.GetAnIntegrationResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.GetAnIntegrationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.GetAnIntegrationResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.GetAnIntegrationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.GetAnIntegrationResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * List Users by workflowId
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListUsersByWorkflowidRequestBuilder listUsersByWorkflowid() {
        return new org.openapis.openapi.models.operations.ListUsersByWorkflowidRequestBuilder(this);
    }

    /**
     * List Users by workflowId
     * @param workflowId The Id of the parent workflow you would like to list users for.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListUsersByWorkflowidResponse listUsersByWorkflowid(
            String workflowId) throws Exception {
        return listUsersByWorkflowid(workflowId, Optional.empty());
    }
    /**
     * List Users by workflowId
     * @param workflowId The Id of the parent workflow you would like to list users for.
     * @param userId The Id of the user you would like to query.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListUsersByWorkflowidResponse listUsersByWorkflowid(
            String workflowId,
            Optional<? extends String> userId) throws Exception {
        org.openapis.openapi.models.operations.ListUsersByWorkflowidRequest request =
            org.openapis.openapi.models.operations.ListUsersByWorkflowidRequest
                .builder()
                .workflowId(workflowId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.ListUsersByWorkflowidRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/users/",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.ListUsersByWorkflowidRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-users-by-workflowid", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-users-by-workflowid", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-users-by-workflowid", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-users-by-workflowid", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListUsersByWorkflowidResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListUsersByWorkflowidResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListUsersByWorkflowidResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListUsersByWorkflowidResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListUsersByWorkflowidResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Upgrade a workflow
     * This endpoint allows you as the ISV to upgrade the workflow for a specified end user.  &lt;br /&gt; &lt;br /&gt;In order to upgrade a workflow via this endpoint, the new workflow must have the same configurable fields as the original. If any new configurable fields were added, you will not be able to upgrade the workflow programmatically and instead would need to reinstall the workflow for the end user.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.UpgradeWorkflowRequestBuilder upgradeWorkflow() {
        return new org.openapis.openapi.models.operations.UpgradeWorkflowRequestBuilder(this);
    }

    /**
     * Upgrade a workflow
     * This endpoint allows you as the ISV to upgrade the workflow for a specified end user.  &lt;br /&gt; &lt;br /&gt;In order to upgrade a workflow via this endpoint, the new workflow must have the same configurable fields as the original. If any new configurable fields were added, you will not be able to upgrade the workflow programmatically and instead would need to reinstall the workflow for the end user.
     * @param workflowId Id of the parent workflow in which you are upgrading for the end user
     * @param userId Id of the end user you wish to upgrade the workflow for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.UpgradeWorkflowResponse upgradeWorkflow(
            String workflowId,
            String userId) throws Exception {
        org.openapis.openapi.models.operations.UpgradeWorkflowRequest request =
            org.openapis.openapi.models.operations.UpgradeWorkflowRequest
                .builder()
                .workflowId(workflowId)
                .userId(userId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.UpgradeWorkflowRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/upgrade",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "PUT");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.UpgradeWorkflowRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("upgrade-workflow", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("upgrade-workflow", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("upgrade-workflow", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("upgrade-workflow", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.UpgradeWorkflowResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.UpgradeWorkflowResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.UpgradeWorkflowResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.UpgradeWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.UpgradeWorkflowResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.UpgradeWorkflowResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.UpgradeWorkflowResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve a list of workflow versions
     * Returns a list of all versions available for a given workflow
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.ListVersionsRequestBuilder listVersions() {
        return new org.openapis.openapi.models.operations.ListVersionsRequestBuilder(this);
    }

    /**
     * Retrieve a list of workflow versions
     * Returns a list of all versions available for a given workflow
     * @param userId The Id of the user you want to lookup. Returned from the Create User endpoint. Note: you can also use the Embedded user's `username` in this field.
     * @param workflowId The Id of the workflow you want to retrieve versions for
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.ListVersionsResponse listVersions(
            String userId,
            String workflowId) throws Exception {
        org.openapis.openapi.models.operations.ListVersionsRequest request =
            org.openapis.openapi.models.operations.ListVersionsRequest
                .builder()
                .userId(userId)
                .workflowId(workflowId)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.ListVersionsRequest.class,
                _baseUrl,
                "/workflows/{workflowId}/versions",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        _req.addQueryParams(Utils.getQueryParams(
                org.openapis.openapi.models.operations.ListVersionsRequest.class,
                request, 
                null));

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("list-versions", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("list-versions", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("list-versions", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("list-versions", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.ListVersionsResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.ListVersionsResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.ListVersionsResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            // no content 
            return _res;
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.ListVersionsResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.ListVersionsResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Retrieve credential structure for an app
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.CredentialMedataByAppRequestBuilder credentialMedataByApp() {
        return new org.openapis.openapi.models.operations.CredentialMedataByAppRequestBuilder(this);
    }

    /**
     * Retrieve credential structure for an app
     * @param app Name of App (camelCased, can be found in App Metadata response)
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CredentialMedataByAppResponse credentialMedataByApp(
            String app) throws Exception {
        org.openapis.openapi.models.operations.CredentialMedataByAppRequest request =
            org.openapis.openapi.models.operations.CredentialMedataByAppRequest
                .builder()
                .app(app)
                .build();
        
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                org.openapis.openapi.models.operations.CredentialMedataByAppRequest.class,
                _baseUrl,
                "/metadata/credentials/{app}",
                request, null);
        
        HTTPRequest _req = new HTTPRequest(_url, "GET");
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("credential-medata-by-app", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("credential-medata-by-app", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("credential-medata-by-app", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("credential-medata-by-app", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.CredentialMedataByAppResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.CredentialMedataByAppResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.CredentialMedataByAppResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.CredentialMedataByAppResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.CredentialMedataByAppResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.CredentialMedataByAppResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.CredentialMedataByAppResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Start Installation
     * This endpoint will create an installation record and return the information required to create a form for your user to fill out.
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.StartInstallationRequestBuilder startInstallation() {
        return new org.openapis.openapi.models.operations.StartInstallationRequestBuilder(this);
    }

    /**
     * Start Installation
     * This endpoint will create an installation record and return the information required to create a form for your user to fill out.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.StartInstallationResponse startInstallationDirect() throws Exception {
        return startInstallation(Optional.empty());
    }
    /**
     * Start Installation
     * This endpoint will create an installation record and return the information required to create a form for your user to fill out.
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.StartInstallationResponse startInstallation(
            Optional<? extends org.openapis.openapi.models.operations.StartInstallationRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/headless/startInstallation");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.StartInstallationRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        Utils.configureSecurity(_req,  
                this.sdkConfiguration.securitySource.getSecurity());

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("start-installation", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("start-installation", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("start-installation", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("start-installation", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.StartInstallationResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.StartInstallationResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.StartInstallationResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.StartInstallationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.StartInstallationResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.StartInstallationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.StartInstallationResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }

    /**
     * Complete Installation
     * @return The call builder
     */
    public org.openapis.openapi.models.operations.CompleteInstallationRequestBuilder completeInstallation() {
        return new org.openapis.openapi.models.operations.CompleteInstallationRequestBuilder(this);
    }

    /**
     * Complete Installation
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CompleteInstallationResponse completeInstallationDirect() throws Exception {
        return completeInstallation(Optional.empty());
    }
    /**
     * Complete Installation
     * @param request The request object containing all of the parameters for the API call.
     * @return The response from the API call
     * @throws Exception if the API call fails
     */
    public org.openapis.openapi.models.operations.CompleteInstallationResponse completeInstallation(
            Optional<? extends org.openapis.openapi.models.operations.CompleteInstallationRequestBody> request) throws Exception {
        String _baseUrl = this.sdkConfiguration.serverUrl;
        String _url = Utils.generateURL(
                _baseUrl,
                "/headless/completeInstallation");
        
        HTTPRequest _req = new HTTPRequest(_url, "POST");
        Object _convertedRequest = Utils.convertToShape(request, Utils.JsonShape.DEFAULT,
            new TypeReference<Optional<? extends org.openapis.openapi.models.operations.CompleteInstallationRequestBody>>() {});
        SerializedBody _serializedRequestBody = Utils.serializeRequestBody(
                _convertedRequest, "request", "json", false);
        _req.setBody(Optional.ofNullable(_serializedRequestBody));
        _req.addHeader("Accept", "application/json")
            .addHeader("user-agent", 
                this.sdkConfiguration.userAgent);

        Utils.configureSecurity(_req,  
                this.sdkConfiguration.securitySource.getSecurity());

        HTTPClient _client = this.sdkConfiguration.defaultClient;
        HttpRequest _r = 
            sdkConfiguration.hooks()
               .beforeRequest(
                  new BeforeRequestContextImpl("complete-installation", sdkConfiguration.securitySource()),
                  _req.build());
        HttpResponse<InputStream> _httpRes;
        try {
            _httpRes = _client.send(_r);
            if (Utils.statusCodeMatches(_httpRes.statusCode(), "400", "4XX", "5XX")) {
                _httpRes = sdkConfiguration.hooks()
                    .afterError(
                        new AfterErrorContextImpl("complete-installation", sdkConfiguration.securitySource()),
                        Optional.of(_httpRes),
                        Optional.empty());
            } else {
                _httpRes = sdkConfiguration.hooks()
                    .afterSuccess(
                        new AfterSuccessContextImpl("complete-installation", sdkConfiguration.securitySource()),
                         _httpRes);
            }
        } catch (Exception _e) {
            _httpRes = sdkConfiguration.hooks()
                    .afterError(new AfterErrorContextImpl("complete-installation", sdkConfiguration.securitySource()), 
                        Optional.empty(),
                        Optional.of(_e));
        }
        String _contentType = _httpRes
            .headers()
            .firstValue("Content-Type")
            .orElse("application/octet-stream");
        org.openapis.openapi.models.operations.CompleteInstallationResponse.Builder _resBuilder = 
            org.openapis.openapi.models.operations.CompleteInstallationResponse
                .builder()
                .contentType(_contentType)
                .statusCode(_httpRes.statusCode())
                .rawResponse(_httpRes);

        org.openapis.openapi.models.operations.CompleteInstallationResponse _res = _resBuilder.build();
        
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "200")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.operations.CompleteInstallationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.operations.CompleteInstallationResponseBody>() {});
                _res.withObject(java.util.Optional.ofNullable(_out));
                return _res;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "400")) {
            if (Utils.contentTypeMatches(_contentType, "application/json")) {
                org.openapis.openapi.models.errors.CompleteInstallationResponseBody _out = Utils.mapper().readValue(
                    Utils.toUtf8AndClose(_httpRes.body()),
                    new TypeReference<org.openapis.openapi.models.errors.CompleteInstallationResponseBody>() {});
                    _out.withRawResponse(java.util.Optional.ofNullable(_httpRes));
                
                throw _out;
            } else {
                throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "Unexpected content-type received: " + _contentType, 
                    Utils.toByteArrayAndClose(_httpRes.body()));
            }
        }
        if (Utils.statusCodeMatches(_httpRes.statusCode(), "4XX", "5XX")) {
            // no content 
            throw new SDKError(
                    _httpRes, 
                    _httpRes.statusCode(), 
                    "API error occurred", 
                    Utils.toByteArrayAndClose(_httpRes.body()));
        }
        throw new SDKError(
            _httpRes, 
            _httpRes.statusCode(), 
            "Unexpected status code received: " + _httpRes.statusCode(), 
            Utils.toByteArrayAndClose(_httpRes.body()));
    }
}
